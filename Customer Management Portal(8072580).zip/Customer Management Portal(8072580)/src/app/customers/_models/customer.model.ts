import { Order } from '../_models/order.model';
export interface Customer {
    id?: number;
    firstName: string;
    lastName: string;
    address: string;
    email: string;
    password: string;
    role: string;
    gender: string;
    city: string;
    state: string;
    order: Order;
}
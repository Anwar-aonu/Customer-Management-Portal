export interface Order {
    productName: string;
    itemCost: string;
    status: string;
    expectedDeliveryDate: Date;
}
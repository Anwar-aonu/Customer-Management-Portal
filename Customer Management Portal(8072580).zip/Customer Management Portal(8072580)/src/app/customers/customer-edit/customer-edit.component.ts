import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';

import { Observable } from 'rxjs';

import * as customerActions from '../state/customer.actions';
import * as fromCustomer from '../state/customer.reducer';
import { Customer } from '../_models/customer.model';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.css']
})
export class CustomerEditComponent implements OnInit {

  customerForm: FormGroup;
  submitted: boolean = false;
  stateArr: any;
  cityArr: any;

  constructor(
    private fb: FormBuilder,
    private store: Store<fromCustomer.AppState>,
    private customerService: CustomerService
  ) { }

  ngOnInit() {

    this.customerService.getStates().subscribe(res => {
      this.stateArr = res;
   });

    this.customerForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      address: ['', Validators.required],
      role: ['', Validators.required],
      gender: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      order: [''],
      id: null
    })

    const customer$: Observable<Customer> = this.store.select(
      fromCustomer.getCurrentCustomer
    );

    customer$.subscribe(currentCustomer => {
      if (currentCustomer) {
        this.customerForm.patchValue({
          firstName: currentCustomer.firstName,
          lastName: currentCustomer.lastName,
          address: currentCustomer.address,
          email: currentCustomer.email,
          password: currentCustomer.password,
          role: currentCustomer.role,
          gender: currentCustomer.gender,
          city: currentCustomer.city,
          state: currentCustomer.state,
          id: currentCustomer.id,
          order: currentCustomer.order
        });
      }
    });
  }

  get f() { return this.customerForm.controls;}

  updateCustomer() {
    this.submitted = true;

    if (this.customerForm.invalid) {
      return;
    }
    const updatedCustomer: Customer = {
      firstName: this.customerForm.get('firstName').value,
      lastName: this.customerForm.get('lastName').value,
      address: this.customerForm.get('address').value,
      role: this.customerForm.get('role').value,
      gender: this.customerForm.get('gender').value,
      city: this.customerForm.get('city').value,
      state: this.customerForm.get('state').value,
      id: this.customerForm.get('id').value,
      order: this.customerForm.get('order').value,
      email: this.customerForm.get('email').value,
      password: this.customerForm.get('password').value
    };

    this.store.dispatch(new customerActions.UpdateCustomer(updatedCustomer));
  }

  getCity(event){
    var obj = {
      states_id: event.target.value
    }
    this.customerService.getCity(obj).subscribe(res => {
        this.cityArr = res;
    });
}

}

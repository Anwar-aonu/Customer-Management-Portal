import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';

import * as customerActions from '../state/customer.actions';
import * as fromCustomer from '../state/customer.reducer';
import { Customer } from '../_models/customer.model';

@Component({
  selector: 'app-totalorders',
  templateUrl: './totalorders.component.html',
  styleUrls: ['./totalorders.component.css']
})
export class TotalordersComponent implements OnInit {

  customers$: Observable<Customer[]>;
  error$: Observable<string>;
  cusArr: any;
  page: 1;
  page2: 1;

  constructor(private store: Store<fromCustomer.AppState>) {}

  ngOnInit() {
    this.store.dispatch(new customerActions.LoadCustomers());
    this.customers$ = this.store.pipe(select(fromCustomer.getCustomers));
    (this.customers$).subscribe( res => {
        this.cusArr = res;
    });
    this.error$ = this.store.pipe(select(fromCustomer.getError));
  }

}

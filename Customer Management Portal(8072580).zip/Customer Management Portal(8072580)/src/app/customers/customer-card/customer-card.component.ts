import { Component, OnInit } from '@angular/core';

import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';

import * as customerActions from '../state/customer.actions';
import * as fromCustomer from '../state/customer.reducer';
import { Customer } from '../_models/customer.model';
import { CustomerService } from '../customer.service';


@Component({
  selector: 'app-customer-card',
  templateUrl: './customer-card.component.html',
  styleUrls: ['./customer-card.component.css']
})
export class CustomerCardComponent implements OnInit {

  customers$: Observable<Customer[]>;
  error$: Observable<string>;
  cusArr: any;
  page: 1;

  constructor(private store: Store<fromCustomer.AppState>,
              private customerService: CustomerService) {}

  ngOnInit() {
    this.store.dispatch(new customerActions.LoadCustomers());
    this.customers$ = this.store.pipe(select(fromCustomer.getCustomers));
    (this.customers$).subscribe( res => {
      this.cusArr = res;
    });
    this.error$ = this.store.pipe(select(fromCustomer.getError));
  }

  editCustomer(customer: Customer) {
    this.store.dispatch(new customerActions.LoadCustomer(customer.id));
  }
  
  viewOrders(customer: Customer) {
    this.store.dispatch(new customerActions.LoadCustomer(customer.id));
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store, State, select } from '@ngrx/store';
import * as customerActions from '../state/customer.actions';
import * as fromCustomer from '../state/customer.reducer';
import { Customer } from '../_models/customer.model';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css']
})
export class CustomerAddComponent implements OnInit {

  customerForm: FormGroup;
  submitted: boolean = false;
  stateArr: any;
  cityArr: any;

  constructor(
    private fb: FormBuilder,
    private store: Store<fromCustomer.AppState>,
    private customerService: CustomerService
  ) {}

  ngOnInit() {
    this.customerService.getStates().subscribe(res => {
      console.log(res);
      this.stateArr = res;
   });
    this.customerForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      address: ['', Validators.required],
      email: ['', Validators.required],
      gender: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      role: ['', Validators.required],
      order: [''],
      password: ['',Validators.required]
    });
  }
 
   get f() { return this.customerForm.controls; }

  createCustomer() {
    this.submitted = true;

    if (this.customerForm.invalid) {
      return;
    }
    const newCustomer: Customer = {
    firstName: this.customerForm.get('firstName').value,
    lastName: this.customerForm.get('lastName').value,
    address: this.customerForm.get('address').value,
    email: this.customerForm.get('email').value,
    password: this.customerForm.get('password').value,
    gender: this.customerForm.get('gender').value,
    city: this.customerForm.get('city').value,
    state: this.customerForm.get('state').value,
    role: this.customerForm.get('role').value,
    order: this.customerForm.get('order').value
    };

    this.store.dispatch(new customerActions.CreateCustomer(newCustomer));

    this.customerForm.reset();
  }

  getCity(event){
      var obj = {
        states_id: event.target.value
      }
      console.log(obj);
      this.customerService.getCity(obj).subscribe(res => {
          console.log(res);
          this.cityArr = res;
      });
  }
}

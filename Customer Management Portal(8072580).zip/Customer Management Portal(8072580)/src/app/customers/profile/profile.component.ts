import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import { Observable } from 'rxjs';
import * as fromCustomer from '../state/customer.reducer';
import { Customer } from '../_models/customer.model';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  customer:any;

  constructor(private store: Store<fromCustomer.AppState> ) { }

  ngOnInit(): void {

    const customer$: Observable<Customer> = this.store.select(
      fromCustomer.getCurrentCustomer
    );
    customer$.subscribe( res => {
      this.customer = res;
      });
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { NgxPaginationModule } from 'ngx-pagination';
import { AgmCoreModule } from '@agm/core';
import { AuthGuardService } from '../_services/auth-guard.service';

import { customerReducer } from './state/customer.reducer';
import { CustomerEffect } from './state/customer.effects';
import { CustomerComponent } from './customer/customer.component';
import { CustomerAddComponent } from './customer-add/customer-add.component';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerCardComponent } from './customer-card/customer-card.component';
import { MapComponent } from './map/map.component';
import { ProfileComponent } from './profile/profile.component';
import { TotalordersComponent } from './totalorders/totalorders.component';


const customerRoutes: Routes = [
  { path: 'customers', component: CustomerComponent ,
  canActivate: [AuthGuardService]},
  { path: 'list', component: CustomerListComponent ,
  canActivate: [AuthGuardService]},
  { path: 'add', component: CustomerAddComponent,
  canActivate: [AuthGuardService] },
  { path: 'edit', component: CustomerEditComponent ,
  canActivate: [AuthGuardService]},
  { path: '', component: CustomerCardComponent,
  canActivate: [AuthGuardService]},
  { path: 'card', component: CustomerCardComponent,
  canActivate: [AuthGuardService]},
  { path: 'map', component: MapComponent,
  canActivate: [AuthGuardService]},
  { path: 'profile', component: ProfileComponent,
  canActivate: [AuthGuardService]},
  { path: 'orders', component: TotalordersComponent,
  canActivate: [AuthGuardService]}
];

@NgModule({
  declarations: [
    CustomerComponent,
    CustomerAddComponent,
    CustomerEditComponent,
    CustomerListComponent,
    CustomerCardComponent,
    MapComponent,
    ProfileComponent,
    TotalordersComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAjUHpiDhHJwK0vCMayeOTvEB08RXI1YCg',
      //apiKey: 'AIzaSyCjS73CI19s-fDuJbhaYKtb_a7XnEz3EsM',
      libraries: ['places']
    }),
    FormsModule,
    RouterModule.forChild(customerRoutes),
    StoreModule.forFeature('customers', customerReducer),
    EffectsModule.forFeature([CustomerEffect])
  ],
  exports: [
    CustomerComponent,
    TotalordersComponent
  ]
})
export class CustomersModule { }

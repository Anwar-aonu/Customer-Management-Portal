import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [
  { path: 'about', component:  AboutComponent },
  { path: 'login', component:  LoginComponent },
  { path: '', component:  LoginComponent },
  {
    path: 'customers',
    loadChildren: '../app/customers/customers.module#CustomersModule'
  }
];

@NgModule({
  imports: [CommonModule, RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

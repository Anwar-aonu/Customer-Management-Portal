import { Injectable } from '@angular/core';
import { CustomerService } from '../customers/customer.service';
import { Customer } from '../customers/_models/customer.model';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  userArr: Customer[];
  constructor(private customerService: CustomerService) { }

  login(username: string, password: string): boolean { 
    this.customerService.getCustomers().subscribe(res => {
      this.userArr = res;
    }) 
    for(let i=0; i<this.userArr.length; i++)
    {
      if (this.userArr[i].email == username && this.userArr[i].password == password) {
        localStorage.setItem('currentUser', 'loggedin');
        return true;
      }
    }
    return false;
  }
  logout(){
    localStorage.removeItem('currentUser');
  }
  public get loggedIn(): boolean {
    return (localStorage.getItem('currentUser') !== null);
  }
}
